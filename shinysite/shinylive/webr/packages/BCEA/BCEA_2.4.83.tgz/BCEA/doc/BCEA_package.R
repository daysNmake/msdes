## ----setup, include=FALSE-----------------------------------------------------
# Needed because the title is different than the vignette entry
options(rmarkdown.html_vignette.check_title = FALSE)

